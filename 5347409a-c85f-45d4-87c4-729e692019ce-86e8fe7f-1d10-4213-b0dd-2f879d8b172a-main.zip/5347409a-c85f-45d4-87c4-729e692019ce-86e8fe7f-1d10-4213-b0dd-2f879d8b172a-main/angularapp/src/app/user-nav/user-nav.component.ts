import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-nav',
  templateUrl: './user-nav.component.html',
  styleUrls: ['./user-nav.component.css']
})
export class UserNavComponent implements OnInit {
isAdmin:boolean = false;
  constructor() { }

  ngOnInit(): void {
  this.isAdmin = localStorage.getItem('userDetails').includes('ROLE_ADMIN');
  }

}
