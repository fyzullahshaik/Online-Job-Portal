
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { ApplicationListComponent } from './application-list/application-list.component';
import { PaymentsComponent } from './payments/payments.component';
import { LoginComponent } from './login/login.component';
import { CreateJobComponent } from './create-job/create-job.component';
import { RequestInterceptorInterceptor } from './interceptors/request-interceptor.interceptor';
import { ErrorComponent } from './error/error.component';
import { LoaderComponent } from './loader/loader.component';
import { JobsListComponent } from './jobs-list/jobs-list.component';
import { AdminNavComponent } from './admin-nav/admin-nav.component';
// import { ApplicantNavComponent } from './applicant-nav/applicant-nav.component';
// import { UserNavComponent } from './user-nav/user-nav.component';
import { NavbarComponent } from './navbar/navbar.component';
import { JobsFilterPipe } from './pipes/jobs-filter.pipe';
import { DateSorterPipe } from './pipes/date-sorter.pipe';
import { JobSearchPipe } from './pipes/job-search.pipe';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegistrationComponent,
    ApplicationListComponent,
    PaymentsComponent,
    LoginComponent,
    CreateJobComponent,
    JobsListComponent,
    ErrorComponent,
    LoaderComponent,
    AdminNavComponent,
    // ApplicantNavComponent,
    // UserNavComponent,
    NavbarComponent,
    JobsFilterPipe,
    DateSorterPipe,
    JobSearchPipe
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [
    {provide:HTTP_INTERCEPTORS , useClass : RequestInterceptorInterceptor , multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
 