//frontEndUrl
export const backendUrl = 'https://ide-eaaedbdbddcebfaccbbcefaefefdbddfdba.premiumproject.examly.io/proxy/8080/api/';
//createjob component
export const CREATE_JOB_PAGE_CONSTANTS = {
    JOB_TITLE_LABEL: 'Job Title:',
    JOB_TITLE_VALIDATION_MESSAGE: 'Job Title is required',
    DEPARTMENT_LABEL: 'Department:',
    DEPARTMENT_REQUIRED_VALIDATION_MESSAGE: 'Department is required',
    LOCATION_LABEL: 'Location:',
    LOCATION_REQUIRED_VALIDATION_MESSAGE: 'Location is required',
    RESPONSIBILITY_LABEL: 'Responsibility:',
    RESPONSIBILITY_REQUIRED_VALIDATION_MESSAGE: 'Responsibility is required',
    QUALIFICATION_LABEL: 'Qualification:',
    QUALIFICATION_REQUIRED_VALIDATION_MESSAGE: 'Qualification is required',
    DEADLINE_LABEL: 'Deadline:',
    DEADLINE_REQUIRED_VALIDATION_MESSAGE: 'Deadline is required',
    DEADLINE_DURATION_VALIDATION_MESSAGE: 'Deadline must be at least 15 days from today.',
    JOB_CATEGORY_LABEL: 'Application Category:',
    JOB_CATEGORY_VALUES: [
        {
            label: 'GENERAL',
            value: 'General'
        },
        {
            label: 'PREMIUM',
            value: 'Premium'
        }
    ],
    APPLICATION_CATEGORY_REQUIRED_VALIDATION_MESSAGE: 'Category is required',
    SAVE_BUTTON: 'Save Job Posting'
}

//login
export const LOGIN_PAGE_CONSTANTS = {
    USERNAME_PLACEHOLDER: 'Username',
    USERNAME_LABEL: 'Username',
    USERNAME_REQUIRED_VALIDATION_MESSAGE: 'Username is required',
    PASSWORD_PLACEHOLDER: 'Password',
    PASSWORD_LABEL: 'Password',
    PASSWORD_REQUIRED_VALIDATION_MESSAGE: 'Password is required',
    SHOW_PASSWORD_LABEL: 'Show Password',
    LOGIN_BUTTON: 'Login'
};

//REGISTER

export const REGISTRATION_PAGE_CONSTANTS = {
    TITLE: "Registration",
    USERNAME_LABEL: 'Username:',
    EMAIL_LABEL: 'Email:',
    PASSWORD_LABEL: 'Password:',
    CONFIRM_PASSWORD_LABEL: 'Confirm Password:',
    MOBILE_NUMBER_LABEL: 'Mobile Number:',
    ROLE_LABEL: 'Role:',
    USERNAME_REQUIRED_VALIDATION_MESSAGE: 'Username is required',
    EMAIL_REQUIRED_VALIDATION_MESSAGE: 'Email is required',
    EMAIL_INVALID_VALIDATION_MESSAGE: 'Invalid Email Id',
    PASSWORD_INVALID_VALIDATION_MESSAGE: 'Password is required',
    PASSWORD_PATTERN_VALIDATION_MESSAGE: 'Password must include at least one uppercase letter, one lowercase letter, one digit, and one special character',
    CONFIRM_PASSWORD_REQUIRED_VALIDATION_MESSAGE: 'Confirm Password is required',
    MOBILE_NUMBER_REQUIRED_VALIDATION_MESSAGE: 'Mobile number is required',
    USER_ROLE_LABEL: "Select a role",
    USER_ROLE_Values: [
        {
            label: 'ADMIN',
            value: 'ROLE_ADMIN'
        },
        {
            label: 'APPLICANT',
            value: 'ROLE_APPLICANT'
        }
    ],
    USER_ROLE_REQUIRED_VALIDATION_MESSAGE: 'Role is required',
    PASSWORD_MISMATCH_VALIDATION_MESSAGE: 'Passwords do not match',
    REGISTER_BUTTON: 'Register'
};

//edit job
export const EDIT_JOB_CONSTANTS = {
    JOB_TITLE_LABEL : 'Job Title',
    DEPARTMENT_LABEL : 'Department : ',
    LOCATION_LABEL : 'Location : ',
    RESPONSIBILITY_LABEL : 'Responsibility : ',
    QUALIFICATION_LABEL : 'Qualification : ',
    DEADLINE_LABEL : 'Deadline : ',
    APPLICATION_FEE_LABEL : 'Application Fee : ',
    APPLY_BUTTON_LABEL : 'Apply',
    APPLIED_BUTTON_LABEL : 'Applied',
    EDIT_BUTTON_LABEL : 'Edit',
    DELETE_BUTTON_LABEL: 'Delete',
};

//premium
export const APPLY_JOB_MODAL_CONSTANTS = {
    JOB_TITLE_LABEL : 'Job Title :',
    FULL_NAME_LABEL : 'Enter Full Name :',
    FULL_NAME_REQUIRED_VALIDATION_MESSAGE : 'Full Name is required',
    QUALIFICATION_LABEL : 'Qualification :',
    QUALIFICATION_REQUIRED_VALIDATION_MESSAGE : 'Qualification is required',
    EXPERIENCE_LABEL : 'Experience :',
    EXPERIENCE_REQUIRED_VALIDATION_MESSAGE : 'Experience is required',
    SUBMIT_BUTTON_TEXT : 'Submit Application',
    CANCEL_BUTTON_TEXT: 'Cancel',
    FORM_HEADING: 'Provide below details'
};

//payments
export const PAYMENT_MODAL_CONSTANTS = {
    TITLE: 'Make Payment',
    USER_NAME: 'User Name',
    TOTAL_AMOUNT: 'Total Amount',
    PAYMENT_DATE: 'Payment Date',
    MODE_OF_PAYMENT: 'Mode Of Payment'
};