import { Pipe, PipeTransform } from '@angular/core';
import { Job } from '../models/job.model';

@Pipe({
  name: 'dateSorter'
})
export class DateSorterPipe implements PipeTransform {

  transform(jobs: Job[]): Job[] {
    return jobs.sort((a,b)=>{
      return <any>new Date(a.deadline) - <any>new Date(b.deadline);
    })
  }

}
