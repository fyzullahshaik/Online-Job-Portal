import { Pipe, PipeTransform } from '@angular/core';
import { Job } from '../models/job.model';

@Pipe({
  name: 'jobsFilter'
})
export class JobsFilterPipe implements PipeTransform {

  transform(jobs: Job[]): Job[] {
    const currentDate: Date = new Date();
    if (localStorage.getItem('role') != 'ROLE_ADMIN') {
      return jobs.filter(job => new Date(job.deadline).getTime() >= currentDate.getTime());
    } else {
      return jobs;
    }
  }
}
