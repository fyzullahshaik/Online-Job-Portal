import { JobsFilterPipe } from './jobs-filter.pipe';

describe('JobsFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new JobsFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
