import { DateSorterPipe } from './date-sorter.pipe';

describe('DateSorterPipe', () => {
  it('create an instance', () => {
    const pipe = new DateSorterPipe();
    expect(pipe).toBeTruthy();
  });
});
