import { Pipe, PipeTransform } from '@angular/core';
import { Job } from '../models/job.model';

@Pipe({
  name: 'jobSearch'
})
export class JobSearchPipe implements PipeTransform {

  transform(jobs: Job[], searchTerm: string): Job[] {
    if (!searchTerm) {
      return jobs;
    } else {
      console.log(searchTerm);
      
      return jobs.filter(job => 
        JSON.stringify(job).toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
  }

}
