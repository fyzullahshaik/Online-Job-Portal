import { JobSearchPipe } from './job-search.pipe';

describe('JobSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new JobSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
