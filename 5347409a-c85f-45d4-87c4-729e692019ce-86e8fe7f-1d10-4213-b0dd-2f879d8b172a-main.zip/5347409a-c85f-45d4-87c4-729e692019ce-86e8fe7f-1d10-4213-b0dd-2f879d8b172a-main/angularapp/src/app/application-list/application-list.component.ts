import { Component, OnInit } from '@angular/core';
import { ApplicationService } from '../services/application.service';
import { Application } from '../models/application.model';
import Swal from 'sweetalert2';
import { User } from '../models/user.model';

@Component({
  selector: 'app-application-list',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.css']
})
export class ApplicationListComponent implements OnInit {
  userDetails:User ;
  isLoading:boolean = true;
  applications:Application[] = [];
  constructor(private service:ApplicationService) { }

  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails'));
    
    if (localStorage.getItem('userDetails').includes('ROLE_ADMIN')) {
      this.fetchAllAplications();
    } else {
      this.fetchUserApplications();
    }
  }
  
  public get isAdmin() : boolean {
    return this.userDetails.userRole === 'ROLE_ADMIN';
  }
  
  fetchAllAplications()
  {
    this.isLoading = true;
    this.service.getAllApplication().subscribe(result=>{
      this.applications = result;
      console.log(result);
      
      this.isLoading = false;
    })
  }
  fetchUserApplications()
  {
    console.log(this.userDetails);
    
    this.isLoading = true;
    this.service.getApplicationByUserId(this.userDetails.userId).subscribe(result=>{
      this.applications = result;
      this.isLoading = false;
    })
  }
  updateApplicationStatus(status:string , applicationId:number)
  { 
    this.service.updateApplicationStatus(applicationId , status).subscribe(result=>{
      this.fetchAllAplications();
    })
  }
  deleteApplication(applicationId:number)
  {
    Swal.fire({
      text : "Are you sure",
      icon :"warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then(()=>{
      this.service.deleteApplication(applicationId).subscribe(()=>{
        Swal.fire({
          title: "Success",
            text: "Application deleted Successfully",
            icon: "success",
        })
        .then(()=>this.ngOnInit());
      })
    })
  }

}
