import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { JobService } from '../services/job.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { CREATE_JOB_PAGE_CONSTANTS } from '../Constants';

@Component({
  selector: 'app-create-job',
  templateUrl: './create-job.component.html',
  styleUrls: ['./create-job.component.css']
})
export class CreateJobComponent implements OnInit {
  CREATE_JOB_PAGE_CONSTANTS = CREATE_JOB_PAGE_CONSTANTS;
  newJobForm:FormGroup;
  constructor(private builder:FormBuilder, private service:JobService, private router:Router) { }

  
  ngOnInit(): void {
    this.newJobForm = this.builder.group({
      title : this.builder.control('',Validators.required) ,
      dept : this.builder.control('',Validators.required) ,
      location : this.builder.control('',Validators.required) ,
      responsibility : this.builder.control('',Validators.required) ,
      qualification : this.builder.control('',Validators.required) ,
      category : this.builder.control('',Validators.required) ,
      deadline : this.builder.control('',[Validators.required , this.validateDeadline.bind(this)]),
    })
  }

  validateDeadline(control: AbstractControl): ValidationErrors | null {
    const selectedDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
  
    const minAllowedDate = new Date(today);
    minAllowedDate.setDate(today.getDate() + 15);
  
    if (selectedDate < minAllowedDate) {
      return { invalidDeadline: true };
    }
  
    return null;
  }


  public get title(){
    return this.newJobForm.get('title');
  }
  public get dept(){
    return this.newJobForm.get('dept');
  }
  public get location(){
    return this.newJobForm.get('location');
  }
  public get responsibility(){
    return this.newJobForm.get('responsibility');
  }
  public get qualification(){
    return this.newJobForm.get('qualification');
  }
  public get category(){
    return this.newJobForm.get('category');
  }
  public get deadline(){
    return this.newJobForm.get('deadline');
  }
  createJob()
  {
    this.service.createJob(this.newJobForm.value).subscribe((result)=>{
      Swal.fire({title:'Job Added Successfully!!!',text:'You will be Redirected to Jobs Page' , icon:'success'})
      .then(()=>{
        this.router.navigate(['jobs']);
      }) 
    },(error)=>{
      Swal.fire({text:(error.error as string),icon:'error'})   
    })
  }


}
