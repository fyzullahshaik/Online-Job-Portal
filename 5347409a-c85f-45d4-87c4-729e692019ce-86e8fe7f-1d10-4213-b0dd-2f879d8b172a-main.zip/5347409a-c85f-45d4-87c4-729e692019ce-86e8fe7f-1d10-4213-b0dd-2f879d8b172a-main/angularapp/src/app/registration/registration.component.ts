import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2'; 
import { REGISTRATION_PAGE_CONSTANTS } from '../Constants';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  REGISTRATION_PAGE_CONSTANTS = REGISTRATION_PAGE_CONSTANTS;
  passwordMismatch:boolean = false;
  registrationForm:FormGroup;
 
  constructor(private service: AuthService, private router: Router , private builder:FormBuilder) {
    this.registrationForm = builder.group({
      username:builder.control('',Validators.required),
      password:builder.control('',[Validators.required , Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)]),
      confirmPassword:builder.control('',Validators.required),
      userRole:builder.control('',Validators.required),
      email:builder.control('',[Validators.required , Validators.email]),
      mobileNumber:builder.control('',[Validators.required,Validators.pattern(/\d{10}/)])
    })
  }
  ngOnInit(): void {
  }
  
  
  public get username(){
    return this.registrationForm.get('username');
  }
  public get userRole(){
    return this.registrationForm.get('userRole');
  }
  public get email(){
    return this.registrationForm.get('email');
  }
  public get mobileNumber(){
    return this.registrationForm.get('mobileNumber');
  }
  public get password(){
    return this.registrationForm.get('password');
  }
  public get confirmPassword(){
    return this.registrationForm.get('confirmPassword');
  }
  
  
  public isPasswordsMatching() : boolean {
    return (this.password.value as string) === (this.confirmPassword.value as string);
  }
  
  register() {
    if (!this.isPasswordsMatching()) {
      this.passwordMismatch = true;
    } else {
      let user = {...this.registrationForm.value};
      delete user.confirmPassword;
      this.service.register(user).subscribe((result)=>{
        Swal.fire({text:result,icon:"success"}).then(()=>{this.router.navigate(['login'])});
      },
      (error)=>{
        Swal.fire({text:error.error,icon:"error"});
  
      })
    }
    }

}
