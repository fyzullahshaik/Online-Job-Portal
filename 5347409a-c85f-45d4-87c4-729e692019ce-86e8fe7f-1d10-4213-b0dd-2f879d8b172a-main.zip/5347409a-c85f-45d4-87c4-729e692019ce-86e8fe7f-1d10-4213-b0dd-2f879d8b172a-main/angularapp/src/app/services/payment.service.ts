import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Payment } from '../models/payment.model';
import { Observable } from 'rxjs';
import { backendUrl } from '../Constants';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private apiUrl:string = backendUrl;
  constructor(private http:HttpClient) { }

  createPayment(payment:Payment , userId:number):Observable<any>{
    return this.http.post(this.apiUrl+"payment/"+userId,payment);
  }
  getAllPayment():Observable<any>{
    return this.http.get(this.apiUrl+"payment");
  }
  getPaymentByUserId(userId:number):Observable<any>{
    return this.http.get(this.apiUrl+"payment/user/"+userId);
  }
}
