import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CurrentUserService {
  userDetails:User = localStorage.getItem('userDetails') ? JSON.parse(localStorage.getItem('userDetails')) : null;
  constructor() { }
  public isLoggedIn():boolean
  {
    return this.userDetails.username!== null;
  }

  // public isUserLogged():Observable<boolean>
  // {
  //   if(this.userDetails){
  //     return of(true);
  //   }
  //   else{
  //     return of(false);
  //   }
  // }
  public isAdmin():boolean
  {
    return this.userDetails.userRole === 'ROLE_ADMIN';
  }
  public isApplicant():boolean
  {
    return this.userDetails.userRole === 'ROLE_APPLICANT';
  }

  public getUserId():number
  {
    return this.userDetails.userId;
  }

}
