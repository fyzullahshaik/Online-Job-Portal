import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { backendUrl } from '../Constants';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {
  private apiUrl:string = backendUrl;
  constructor(private http:HttpClient) { }

  createApplication(applicant:any):Observable<any>{
    console.log(applicant);
    
    return this.http.post(this.apiUrl+"application",applicant);
  }

  getAllApplication():Observable<any>{
    return this.http.get(this.apiUrl+"application");
  }

  getApplicationByUserId(userId:number):Observable<any>{
    return this.http.get(this.apiUrl+"application/user/"+`${userId}`);
  }

  deleteApplication(id:number):Observable<any>{
    return this.http.delete(this.apiUrl+"application/"+id , {responseType : 'text'});
  }

  updateApplicationStatus(id:number,status:string):Observable<any>{
    return this.http.put(this.apiUrl+"application/"+`${id}`,status , {responseType : 'text'});
  }

}
