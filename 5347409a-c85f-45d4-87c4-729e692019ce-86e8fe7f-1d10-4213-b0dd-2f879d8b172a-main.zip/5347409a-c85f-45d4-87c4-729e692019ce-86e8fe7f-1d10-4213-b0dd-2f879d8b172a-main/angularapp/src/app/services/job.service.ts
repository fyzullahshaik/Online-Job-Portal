import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Job } from '../models/job.model';
import { backendUrl } from '../Constants';

@Injectable({
  providedIn: 'root'
})
export class JobService {
  private apiUrl:string =  backendUrl;
  constructor(private http:HttpClient) { }

  createJob(job:any):Observable<any>{
    return this.http.post(this.apiUrl+"job",job);
  }
  getAllJobs():Observable<any>{
    return this.http.get(this.apiUrl+"job");
  }
  getJobDetails(jobId:number):Observable<any>{
    return this.http.get(`${this.apiUrl}job/${jobId}`);
  }
  getPremiumJobs():Observable<any>{
    return this.http.get(this.apiUrl+"job/premium-job");
  }
  updateJob(jobId:number,job:Job):Observable<any>{
    return this.http.put(this.apiUrl+"job/"+jobId,job);
  }
  deleteJob(jobId:number):Observable<any>{
    return this.http.delete(this.apiUrl+"job/"+jobId , {responseType:'text'});
  }

  getApplicationByUserId(userId:number):Observable<any>{
    return this.http.get(this.apiUrl+"application/user/"+`${userId}`);
  }

}
