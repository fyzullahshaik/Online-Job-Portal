import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { BehaviorSubject, Observable } from 'rxjs';
import { backendUrl } from '../Constants';
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  // private currentUserSubject: BehaviorSubject<string | null>;
  // public currentUser: Observable<string | null>;
  // private userRoleSubject = new BehaviorSubject<string>('');
  // userRole$: Observable<string> = this.userRoleSubject.asObservable();
  // private isAuthenticatedSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.isAuthenticated());
  // isAuthenticated$ = this.isAuthenticatedSubject.asObservable();
  // private premiumUserSubject = new BehaviorSubject<boolean>(false);
  // premiumUser$ = this.premiumUserSubject.asObservable();

  backendUrl:string = backendUrl;
  constructor(private httpClient : HttpClient) { }
 
  public login(user:User):Observable<any>
  {
    return this.httpClient.post(this.backendUrl+'login' , user);
  }
 
 
  public register(user:User):Observable<any>
  {
    return this.httpClient.post(this.backendUrl+'/register' , user,{responseType:'text'});
  }
 
  isAuthenticated(): boolean {
    const token = localStorage.getItem('userDetails');
    return !!token; 
  }

  isAdmin(): boolean {
    return localStorage.getItem('userDetails').includes('ROLE_ADMIN');
  }

  isApplicant(): boolean {
    return localStorage.getItem('userDetails').includes('ROLE_APPLICANT');
  }
  
  // updatePremiumUserStatus(isPremium: boolean) {
  //   this.premiumUserSubject.next(isPremium);
  // }
}