import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private router:Router) {}
  canActivate(route: ActivatedRouteSnapshot):boolean{
    let role=localStorage.getItem('role');
    let commonURLs :string[] = ['/jobs' , '/payments' , '/applications'];
    let currentURL = this.router.getCurrentNavigation().extractedUrl.toString();
      if (!localStorage.getItem('role')) {
        this.router.navigate(["/error"]);
        return false;
      }
      else{
        
        if(role=='ROLE_ADMIN' && (commonURLs.includes(currentURL) || currentURL.includes('createJob'))){
          return true;
        }
        else if (role=='ROLE_APPLICANT' && commonURLs.includes(currentURL))
        {
          return true;
        }
        // else{
        //   this.router.navigate(["/error"]);
        //   return false;
        // }
      }
  }
  
}
