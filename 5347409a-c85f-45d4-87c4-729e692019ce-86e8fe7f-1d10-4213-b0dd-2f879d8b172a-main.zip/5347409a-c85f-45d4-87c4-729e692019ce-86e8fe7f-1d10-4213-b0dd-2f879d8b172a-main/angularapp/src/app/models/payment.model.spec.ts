import { Payment } from './payment.model';

describe('Payment Model', () => {

  fit('frontend_payment model should create an instance', () => {
    // Create a sample user object
    const payment: Payment = {
      status: 'Paid',
    };

    expect(payment).toBeTruthy();
    expect(payment.status).toBe('Paid');

  });
});
