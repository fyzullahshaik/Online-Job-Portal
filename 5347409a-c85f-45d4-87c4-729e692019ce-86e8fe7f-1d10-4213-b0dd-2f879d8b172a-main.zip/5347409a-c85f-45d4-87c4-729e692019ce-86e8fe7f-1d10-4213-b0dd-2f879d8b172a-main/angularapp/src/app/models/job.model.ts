import { Application } from "./application.model";

export interface Job {
    jobId?:number,
    title?:string,
    dept?:string,
    location?:string,
    responsibility?:string,
    qualification?:string,
    category?:string,
    deadline?:Date,
    applications?:Application[]
}
