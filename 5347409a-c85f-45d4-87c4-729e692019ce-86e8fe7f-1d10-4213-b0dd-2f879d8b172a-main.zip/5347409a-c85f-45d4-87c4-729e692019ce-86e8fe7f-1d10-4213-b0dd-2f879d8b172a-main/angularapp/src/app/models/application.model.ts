import { Job } from "./job.model";
import { User } from "./user.model";

export interface Application {
    applicationId?:number,
    fullName?:string,
    qualification?:string,
    experience?:string,
    dateApplied?:Date,
    status?:string,
    job?:Job,
    user?:User
}
