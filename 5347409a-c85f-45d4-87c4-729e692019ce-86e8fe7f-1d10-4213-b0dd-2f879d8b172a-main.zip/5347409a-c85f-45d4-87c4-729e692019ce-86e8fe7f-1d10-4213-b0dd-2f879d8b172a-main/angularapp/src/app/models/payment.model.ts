import { User } from "./user.model";

export interface Payment {
    paymentId?:number,
    status?:string,
    totalAmount?:number,
    modeOfPayment?:string,
    paymentDate?:Date,
    user?:User;
}
