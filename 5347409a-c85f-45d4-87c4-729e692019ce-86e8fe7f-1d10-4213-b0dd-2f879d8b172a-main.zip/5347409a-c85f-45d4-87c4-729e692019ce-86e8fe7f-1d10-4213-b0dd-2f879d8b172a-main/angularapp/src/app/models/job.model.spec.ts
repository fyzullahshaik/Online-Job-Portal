import { Job } from './job.model';

describe('Job Model', () => {

  fit('frontend_job model should create an instance', () => {
    // Create a sample user object
    const job: Job = {
      title: 'Software Developer',
    };

    expect(job).toBeTruthy();
    expect(job.title).toBe('Software Developer');

  });
});
