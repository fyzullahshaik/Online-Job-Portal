import { Application } from './application.model';

describe('Application Model', () => {

  fit('frontend_application model should create an instance', () => {
    // Create a sample user object
    const application: Application = {
      status: 'Applied',
    };

    expect(application).toBeTruthy();
    expect(application.status).toBe('Applied');

  });
});
