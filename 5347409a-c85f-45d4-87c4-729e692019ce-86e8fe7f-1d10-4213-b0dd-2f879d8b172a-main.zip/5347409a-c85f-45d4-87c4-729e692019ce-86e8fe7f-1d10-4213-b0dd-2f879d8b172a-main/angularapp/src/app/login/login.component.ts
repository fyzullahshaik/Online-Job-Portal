import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { LOGIN_PAGE_CONSTANTS } from '../Constants';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  LOGIN_PAGE_CONSTANTS:any = LOGIN_PAGE_CONSTANTS
  loginForm: FormGroup;
  isShowPassword: boolean = false;
  constructor(private builder: FormBuilder, private authService: AuthService,private route:Router) {
    this.loginForm = builder.group({
      username: builder.control('', Validators.required),
      password: builder.control('', Validators.required),
    })
  }
  
  public get username() {
    return this.loginForm.get('username');
  }
  
  public get password() {
    return this.loginForm.get('password');
  }


  
  ngOnInit(): void {
  }

  onLogin() {
    this.authService.login(this.loginForm.value).subscribe((result) => {
      console.log(result);
      
      localStorage.setItem('token' , result.token);      
      localStorage.setItem('userDetails' , JSON.stringify(result.userDetails));
      localStorage.setItem('role' , result.role);
      this.route.navigate(['/jobs']);
    },
      (error) => {
        Swal.fire({text:error.error as string,icon:'error'})
      })

  }

}
