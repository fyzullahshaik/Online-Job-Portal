import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { CreateJobComponent } from './create-job/create-job.component';
import { HomeComponent } from './home/home.component';
import { JobsListComponent } from './jobs-list/jobs-list.component';
import { PaymentsComponent } from './payments/payments.component';
import { ApplicationListComponent } from './application-list/application-list.component';
import { ErrorComponent } from './error/error.component';
import { AuthGuard } from './guards/auth.guard';
// import { UserNavComponent } from './user-nav/user-nav.component';
// import { AdminNavComponent } from './admin-nav/admin-nav.component';
// import { ApplicantNavComponent } from './applicant-nav/applicant-nav.component';
// import { NavbarComponent } from './navbar/navbar.component';

const routes: Routes = [
  // {
  //   path : 'user',
  //   component : UserNavComponent
  // },
  // {
  //   path : 'admin',
  //   component : AdminNavComponent
  // },
  // {
  //   path : 'applicant',
  //   component : ApplicantNavComponent
  // },
  {
    path : 'login',
    component : LoginComponent
  },
  {
    path : 'register',
    component : RegistrationComponent
  },
  {
    path : 'createJob',
    component : CreateJobComponent,
    canActivate : [AuthGuard]
  },
  {
    path : '',
    component : HomeComponent
  },
  {
    path : 'jobs',
    component : JobsListComponent,
    canActivate : [AuthGuard]
  },
  {
    path : 'payments',
    component : PaymentsComponent,
    canActivate : [AuthGuard]
  },
  {
    path : 'applications',
    component : ApplicationListComponent,
    canActivate : [AuthGuard]
  },
  {
    path : "**",
    component : ErrorComponent,
    pathMatch : "full"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
