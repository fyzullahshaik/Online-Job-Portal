import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-nav',
  templateUrl: './admin-nav.component.html',
  styleUrls: ['./admin-nav.component.css']
})
export class AdminNavComponent implements OnInit {
isAdmin:boolean;
  constructor(private router:Router) { }

  ngOnInit(): void {
    this.isAdmin = localStorage.getItem('userDetails').includes('ROLE_ADMIN');
  }

  logout()
  {
    localStorage.setItem('token' , '');
    localStorage.setItem('userDetails' , '');
    localStorage.setItem('role' , '');
    setTimeout(()=>{
      this.router.navigate(['login']);
    },1000);
  }

}
