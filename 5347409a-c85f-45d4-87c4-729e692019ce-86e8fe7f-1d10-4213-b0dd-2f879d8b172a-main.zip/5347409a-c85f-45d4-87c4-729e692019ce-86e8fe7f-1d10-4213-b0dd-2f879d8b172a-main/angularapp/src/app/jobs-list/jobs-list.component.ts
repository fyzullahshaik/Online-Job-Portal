import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Job } from '../models/job.model';
import { JobService } from '../services/job.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Payment } from '../models/payment.model';
import { PaymentService } from '../services/payment.service';
import { User } from '../models/user.model';
import { Application } from '../models/application.model';
import { ApplicationService } from '../services/application.service';
import { AuthService } from '../services/auth.service';
import { APPLY_JOB_MODAL_CONSTANTS, EDIT_JOB_CONSTANTS, PAYMENT_MODAL_CONSTANTS } from '../Constants';

@Component({
  selector: 'app-jobs-list',
  templateUrl: './jobs-list.component.html',
  styleUrls: ['./jobs-list.component.css']
})

export class JobsListComponent implements OnInit {
  @ViewChild('paymentButton', { static: false }) paymentButton: ElementRef;
  @ViewChild('closeEditModal', { static: false }) closeEditModal: ElementRef;
  @ViewChild('applyJobModal', { static: false }) applyJobModal: ElementRef;
  searchTerm:string = '';
  EDIT_JOB_CONSTANTS = EDIT_JOB_CONSTANTS;
  APPLY_JOB_MODAL_CONSTANTS = APPLY_JOB_MODAL_CONSTANTS;
  PAYMENT_MODAL_CONSTANTS = PAYMENT_MODAL_CONSTANTS;
  jobApplyForm: FormGroup;
  expiryDate: Date = new Date();
  editJobForm: FormGroup;
  paymentForm: FormGroup;
  application: Application;
  isPremiumUser: boolean = false;
  payment: Payment;
  job: Job;
  applications: Application[] = [];
  activeCategory: string = 'Free';
  isLoading = true;
  jobs: Job[] = [];
  loggedInUserId: number;
  isAdmin: boolean = localStorage.getItem('userDetails').includes('ROLE_ADMIN')
  constructor(private service: JobService, private router: Router, private builder: FormBuilder, private paymentService: PaymentService, private applicationService: ApplicationService, private authService: AuthService) {
    this.loggedInUserId = parseInt(JSON.parse(localStorage.getItem('userDetails')).userId);
  }

  ngOnInit(): void {
    this.isPremiumUser = localStorage.getItem('userDetails').includes('true');
    this.expiryDate.setMonth(this.expiryDate.getMonth() + 1);
    this.fetchFreeJobs();
    this.initializePaymentForm();
    this.initializeJobEditForm();
    this.initializeJobApplyForm();
    if (!this.isAdmin) {
      this.fetchAllApplications();
    }
  }
  fetchAllApplications() {
    this.service.getApplicationByUserId(this.loggedInUserId).subscribe(result => {
      this.applications = result;
    })
  }

  checkApplicationStatus(jobId: number): boolean {
    return this.applications.some((app) => app.job.jobId === jobId);
  }

  initializeJobEditForm() {
    this.editJobForm = this.builder.group({
      title: this.builder.control(this.job?.title, Validators.required),
      dept: this.builder.control(this.job?.dept, Validators.required),
      location: this.builder.control(this.job?.location, Validators.required),
      responsibility: this.builder.control(this.job?.responsibility, Validators.required),
      qualification: this.builder.control(this.job?.qualification, Validators.required),
      category: this.builder.control(this.job?.category, Validators.required),
      deadline: this.builder.control('', [Validators.required, this.validateDeadline.bind(this)])
    });
  }
  initializePaymentForm() {
    this.paymentForm = this.builder.group({
      cardNumber: this.builder.control('', [Validators.required, Validators.pattern("[0-9]{16}")]),
      cvv: this.builder.control('', [Validators.required, Validators.pattern(/\d{3}/)]),
      totalAmount: this.builder.control({ value: '5000', disabled: true }, [Validators.required, Validators.min(99)]),
      expiryDate: this.builder.control('', Validators.required)
    })
  }
  initializeJobApplyForm() {
    this.jobApplyForm = this.builder.group({
      fullName: this.builder.control(''),
      qualification: this.builder.control('', Validators.required),
      experience: this.builder.control('', Validators.required),
      dateApplied: this.builder.control('', Validators.required),
    })
  }
  getDateFormat(date: Date): string {
    let convertedDate: Date = new Date(date);
    return `${convertedDate.getFullYear()}-${convertedDate.getMonth()}-${convertedDate.getDate()}`
  }

  public get fullName() {
    return this.jobApplyForm.get('fullName');
  }
  public get jobQualification() {
    return this.jobApplyForm.get('qualification');
  }
  public get experience() {
    return this.jobApplyForm.get('experience');
  }
  public get dateApplied() {
    return this.jobApplyForm.get('dateApplied');
  }
  public get cardNumber() {
    return this.paymentForm.get('cardNumber');
  }
  public get cvv() {
    return this.paymentForm.get('cvv');
  }
  public get totalAmount() {
    return this.paymentForm.get('totalAmount');
  }
  public get modeOfPayment() {
    return this.paymentForm.get('modeOfPayment');
  }

  public get title() {
    return this.editJobForm.get('title');
  }
  public get dept() {
    return this.editJobForm.get('dept');
  }
  public get location() {
    return this.editJobForm.get('location');
  }
  public get responsibility() {
    return this.editJobForm.get('responsibility');
  }
  public get qualification() {
    return this.editJobForm.get('qualification');
  }
  public get category() {
    return this.editJobForm.get('category');
  }
  public get deadline() {
    return this.editJobForm.get('deadline');
  }

  isDeadlineExpired(deadline: Date): boolean {
    return new Date(deadline).getTime() < new Date().getTime();
  }
  deleteJob(job: Job) {
    Swal.fire({
      title: `Are you sure to delete ${job.title} job`,
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!"
    }).then((result) => {
      this.service.deleteJob(job.jobId).subscribe(
        (result) => { this.ngOnInit() },
        (error) => {
          Swal.fire({ text: error.error, icon: 'error' })
        }
      )
    });
  }

  fetchFreeJobs() {
    this.activeCategory = 'Free';
    this.isLoading = true;
    this.service.getAllJobs().subscribe((result) => {
      this.jobs = result;
      this.isLoading = false;
    });
  }

  fetchPremiumJobs() {
    this.activeCategory = 'Premium';
    this.isLoading = true;
    this.service.getPremiumJobs().subscribe(result => {
      this.jobs = result;
      this.isLoading = false;
    })
  }
  makePayment() {
    this.paymentButton.nativeElement.click();
    let user: User = JSON.parse(localStorage.getItem('userDetails'));
    this.payment = {
      totalAmount: 5000,
      modeOfPayment: 'Credit Card',
      ...this.paymentForm.value,
      paymentDate: new Date(),
      status: 'Confirmed'
    };
    console.log(this.payment);

    this.paymentService.createPayment(this.payment, user.userId).subscribe(result => {
      Swal.fire({
        title: 'Success',
        text: 'Payment Done Successfully',
        icon: 'success'
      }).then(() => {
        user.isPremiumUser = true;
        localStorage.setItem('userDetails', JSON.stringify(user));
        window.location.reload();
      })
    })

  }

  setJobToUpdate(job: Job) {
    this.editJobForm.patchValue(job);
    this.job = { ...job };
  }
  updateJobDetails() {

    this.job = {
      ...this.editJobForm.value,
      jobId: this.job.jobId
    };

    this.service.updateJob(this.job.jobId, this.job).subscribe(result => {
      Swal.fire({ text: 'Job details updated successfully', title: 'Success', icon: 'success' }).then(() => {
        this.ngOnInit();
        this.cancelEdit();
      })
    })
  }
  cancelEdit() {
    this.closeEditModal.nativeElement.click();
    this.job = null;
  }

  // job apply

  applyJob(job: Job) {
    this.job = job;

  }
  submitJobApplication() {
    this.application = { ...this.jobApplyForm.value, status: 'Submitted', job: this.job, dateApplied: new Date(), user: { userId: this.loggedInUserId } }
    if (Object.values(this.application).some(value => value == '')) {
      Swal.fire({ text: 'Please fill the details', icon: 'error' });
      return;
    } else {
      this.applyJobModal.nativeElement.click();
      delete this.application.job.applications;
      this.applicationService.createApplication(this.application).subscribe(result => {
        Swal.fire({
          title: 'Success',
          text: 'Applied successfully',
          icon: 'success'
        }).then(() => {
          this.ngOnInit();
        })
      })
    }

  }


  validateDeadline(control: AbstractControl): ValidationErrors | null {
    const selectedDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const minAllowedDate = new Date(today);
    minAllowedDate.setDate(today.getDate() + 15);

    if (selectedDate < minAllowedDate) {
      return { invalidDeadline: true };
    }

    return null;
  }
}
