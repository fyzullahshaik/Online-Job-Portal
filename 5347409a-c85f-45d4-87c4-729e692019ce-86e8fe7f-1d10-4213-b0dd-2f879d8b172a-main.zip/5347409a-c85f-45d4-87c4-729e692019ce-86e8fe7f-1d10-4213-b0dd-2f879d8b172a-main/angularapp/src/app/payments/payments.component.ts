import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../services/payment.service';
import { Payment } from '../models/payment.model';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.css']
})
export class PaymentsComponent implements OnInit {
  payments:Payment[] = [];
  loggedInUserId:number;
  isLoding:boolean = true;
  constructor(private service:PaymentService) { 
    this.loggedInUserId = parseInt(JSON.parse(localStorage.getItem('userDetails')).userId);
  }

  ngOnInit(): void {
    if (localStorage.getItem('userDetails').includes('ROLE_ADMIN')) {
      this.fetchAllPayments();
    } else {
      this.fetchUserPayents();
    }
   }

   fetchUserPayents()
   {
    this.service.getPaymentByUserId(this.loggedInUserId).subscribe(result=>{
      this.payments = result;
      this.isLoding = false;
    })
   }

  fetchAllPayments()
  {
    this.service.getAllPayment().subscribe(result=>{
      this.payments = result;
      this.isLoding = false;
    })
  }

}
