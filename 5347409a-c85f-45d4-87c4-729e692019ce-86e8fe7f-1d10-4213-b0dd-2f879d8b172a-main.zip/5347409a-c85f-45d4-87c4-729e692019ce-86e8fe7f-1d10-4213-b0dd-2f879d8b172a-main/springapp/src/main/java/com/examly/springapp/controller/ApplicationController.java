package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.examly.springapp.model.Application;
import com.examly.springapp.service.ApplicationServiceImpl;

@RestController
@RequestMapping("/api/")
public class ApplicationController {
    private ApplicationServiceImpl applicationService;

    @Autowired
    public ApplicationController(ApplicationServiceImpl applicationService) {
        this.applicationService = applicationService;
    }

    @GetMapping("application")
    public ResponseEntity<List<Application>> allApplication() {
        return new ResponseEntity<>(applicationService.getAllApplications(), HttpStatus.OK);
    }

    @GetMapping("application/user/{userId}")
    public ResponseEntity<List<Application>> fetchUserApplications(@PathVariable int userId) {
        return new ResponseEntity<>(applicationService.getApplicationByUserId(userId), HttpStatus.OK);
    }

    @PostMapping("application")
    public ResponseEntity<Application> addApplication(@RequestBody Application application) {
        return ResponseEntity.status(HttpStatus.CREATED).body(applicationService.addApplication(application));
    }

    @DeleteMapping("application/{applicationId}")
    public ResponseEntity<String> deleteApplication(@PathVariable int applicationId) {
        return ResponseEntity.status(HttpStatus.OK).body(applicationService.deleteApplication(applicationId));
    }

    @GetMapping("job/application/{jobId}")
    public ResponseEntity<List<Application>> fetchJobApplications(@PathVariable long jobId) {
        return new ResponseEntity<>(applicationService.getJobApplications(jobId), HttpStatus.OK);
    }

    @PutMapping("application/{applicationId}")
    public ResponseEntity<String> updateApplicationStatus(@PathVariable("applicationId") long applicationId,
            @RequestBody String status) {
        return new ResponseEntity<>(applicationService.updateApplicationStatus(applicationId, status), HttpStatus.OK);
    }

}
