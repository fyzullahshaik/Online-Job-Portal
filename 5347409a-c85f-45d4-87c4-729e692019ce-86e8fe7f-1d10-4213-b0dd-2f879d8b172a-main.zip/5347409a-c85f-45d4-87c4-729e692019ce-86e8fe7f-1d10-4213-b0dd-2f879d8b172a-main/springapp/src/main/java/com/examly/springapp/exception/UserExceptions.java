package com.examly.springapp.exception;

public class UserExceptions extends RuntimeException{
    public UserExceptions(String userExceptionMessage)
    {
        super(userExceptionMessage);   
    }
}
