package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Payment;
import com.examly.springapp.service.PaymentService;

@RestController
@RequestMapping("/api/")
public class PaymentController {
    private PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("payment")
    public ResponseEntity<List<Payment>> getAllPayments() {
        return ResponseEntity.status(200).body(paymentService.getAllPayment());
    }

    @PostMapping("payment/{userId}")
    public ResponseEntity<Payment> addPayment(@RequestBody Payment payment, @PathVariable("userId") long userId) {
        return ResponseEntity.status(201).body(paymentService.addPayment(payment, userId));
    }

    @GetMapping("payment/user/{userId}")
    public ResponseEntity<List<Payment>> getPaymentByUserId(@PathVariable("userId") long userId) {
        return ResponseEntity.status(200).body(paymentService.getPaymentByUserId(userId));
    }

}
