package com.examly.springapp.service;

import com.examly.springapp.model.User;

public interface UserService {
    String userRegister(User newUser);
    String userLogin(User user);
}
