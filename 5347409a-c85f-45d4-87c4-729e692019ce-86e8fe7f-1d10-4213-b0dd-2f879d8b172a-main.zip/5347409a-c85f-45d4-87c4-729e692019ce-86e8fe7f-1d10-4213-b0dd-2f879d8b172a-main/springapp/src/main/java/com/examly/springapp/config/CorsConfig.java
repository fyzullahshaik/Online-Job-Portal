package com.examly.springapp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CorsConfig {
    @Value("${frontendURL}")
    private String frontendURL;
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration cors = new CorsConfiguration();
        cors.setAllowCredentials(true);
        cors.addAllowedOrigin(frontendURL);
        cors.addAllowedHeader("*");
        cors.addAllowedMethod("*");
        // cors.addAllowedMethod("GET");
        // cors.addAllowedMethod("POST");
        // cors.addAllowedMethod("PUT");
        // cors.addAllowedMethod("DELETE");
        // cors.setAllowedMethods(Arrays.asList("DELETE", "GET", "POST", "PATCH", "PUT",
        // "OPTIONS"));
        // cors.addAllowedMethod(Arrays.asList("DELETE", "GET", "POST", "PATCH", "PUT",
        // "OPTIONS"));
        source.registerCorsConfiguration("/**", cors);
        return new CorsFilter(source);

    }
}
