package com.examly.springapp.exception;

public class JobDeletionFailedException extends RuntimeException{

    public JobDeletionFailedException(String exceptionMessage)
    {
        super(exceptionMessage);
    }

}
