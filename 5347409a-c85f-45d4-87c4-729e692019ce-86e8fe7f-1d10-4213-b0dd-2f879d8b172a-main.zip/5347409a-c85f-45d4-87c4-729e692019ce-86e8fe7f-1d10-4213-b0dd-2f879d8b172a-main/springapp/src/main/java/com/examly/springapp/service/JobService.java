package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.Job;

public interface JobService {

    Job addJob(Job job);
    
    List<Job> getAllJobs();

    Job updateJob(long jobId , Job job);

    String deleteJob(long jobId);

    Job getJobById(long jobId);

    List<Job> getPremiumJobs();
}
