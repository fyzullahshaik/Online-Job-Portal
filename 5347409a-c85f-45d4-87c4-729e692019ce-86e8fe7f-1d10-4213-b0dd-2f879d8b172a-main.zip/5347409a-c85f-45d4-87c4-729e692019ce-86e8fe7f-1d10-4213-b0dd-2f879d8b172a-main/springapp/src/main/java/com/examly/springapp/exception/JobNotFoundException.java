package com.examly.springapp.exception;

public class JobNotFoundException extends RuntimeException{

    public JobNotFoundException(String exceptionMessage)
    {
        super(exceptionMessage);
    }
}
