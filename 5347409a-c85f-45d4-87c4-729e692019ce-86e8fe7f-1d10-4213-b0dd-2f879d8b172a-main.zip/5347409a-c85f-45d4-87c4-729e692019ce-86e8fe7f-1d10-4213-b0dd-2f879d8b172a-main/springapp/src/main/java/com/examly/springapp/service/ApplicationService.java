package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.Application;

public interface ApplicationService {
    public Application getApplicationById(long applicationId);
    public List<Application> getApplicationByUserId(long userId);
    public List<Application> getAllApplications();
    public Application addApplication(Application application);
    public String deleteApplication(long applicationId);
}
