package com.examly.springapp.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.config.JwtUtils;
import com.examly.springapp.model.User;
import com.examly.springapp.model.UserDto;
import com.examly.springapp.service.UserServiceImpl;

@RestController
public class AuthController {

    private UserServiceImpl userService;

    private JwtUtils jwtService;

    private AuthenticationManager authenticationManager;

    @Autowired
    public AuthController(UserServiceImpl userService, JwtUtils jwtService,
            AuthenticationManager authenticationManager) {
        this.userService = userService;
        this.jwtService = jwtService;
        this.authenticationManager = authenticationManager;
    }

    @PostMapping("/api/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.userRegister(user));
    }

    @PostMapping("/api/login")
    public UserDto loginUser(@RequestBody User user) {
        UserDto userResponse = new UserDto();
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword()));
        if (authentication.isAuthenticated()) {
            userResponse.setToken(jwtService.GenerateToken(user.getUsername()));
            User loggingUser = userService.findUserByUsername(user.getUsername());
            userResponse.setRole(loggingUser.getUserRole());
            loggingUser.setPassword(null);
            userResponse.setUserDetails(loggingUser);
            return userResponse;
        } else {
            throw new UsernameNotFoundException("Username not found");
        }
    }

}
