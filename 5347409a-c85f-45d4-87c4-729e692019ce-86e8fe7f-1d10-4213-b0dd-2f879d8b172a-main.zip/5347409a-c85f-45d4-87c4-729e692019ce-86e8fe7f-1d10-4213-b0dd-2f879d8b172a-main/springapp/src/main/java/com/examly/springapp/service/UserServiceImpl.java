package com.examly.springapp.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.UserExistsException;
import com.examly.springapp.model.Application;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserServiceImpl implements UserService {
    private UserRepository userRepository;
    private PasswordEncoder encoder;
    
    @Autowired
    public UserServiceImpl(UserRepository userRepository, PasswordEncoder encoder) {
        this.userRepository = userRepository;
        this.encoder = encoder;
    }

    @Transactional
    public String userRegister(User newUser) {
        if (userRepository.existsByUsername(newUser.getUsername())) {
            throw new UserExistsException("Username already exists!!!!");
        } else if (userRepository.existsByEmail(newUser.getEmail())) {
            throw new UserExistsException("Email already exists!!!!");
        } else if (userRepository.existsByMobileNumber(newUser.getMobileNumber())) {
            throw new UserExistsException("Mobile Number already exists!!!!");
        } else {
            newUser.setPassword(encoder.encode(newUser.getPassword()));
            userRepository.save(newUser);
            return "Registration Success!!";
        }

    }

    public String userLogin(User user) {
        return null;
    }

    @Transactional
    public User fetchUser(long userId) {
        return userRepository.findById(userId).orElse(null);
    }

    @Transactional
    public List<Application> fetchUserApplications(long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user != null) {
            return user.getApplications();
        } else {
            return List.of();
        }
    }

    @Transactional
    public User findUserByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }

    @Transactional
    public User updateUser(User user) {
        return userRepository.save(user);
    }

}
