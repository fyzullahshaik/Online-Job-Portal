package com.examly.springapp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(UserExistsException.class)
    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleUserNotFoundException(Exception userNotFoundException)
    {
        return userNotFoundException.getMessage();
    }

    @ExceptionHandler(UserExceptions.class)
    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleuserExceptionMessage(Exception userException)
    {
        return userException.getMessage();
    }
    
    @ExceptionHandler(UsernameNotFoundException.class)
    @ResponseStatus(code = HttpStatus.NOT_FOUND)
    public String handleUsernameNotFoundException(Exception userException)
    {
        return userException.getMessage();
    }

    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(code = HttpStatus.UNAUTHORIZED)
    public String handleAuthenticationException(Exception userException)
    {
        return "Invalid Credentials";
    }
    
    @ExceptionHandler(JobNotFoundException.class)
    @ResponseStatus(code = HttpStatus.NOT_FOUND)
    public String handleJobNotFoundException(Exception jobException)
    {
        return jobException.getMessage();
    }


    @ExceptionHandler(JobDeletionFailedException.class)
    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleJobDeletionFailedException(Exception jobException)
    {
        return jobException.getMessage();
    }


}
