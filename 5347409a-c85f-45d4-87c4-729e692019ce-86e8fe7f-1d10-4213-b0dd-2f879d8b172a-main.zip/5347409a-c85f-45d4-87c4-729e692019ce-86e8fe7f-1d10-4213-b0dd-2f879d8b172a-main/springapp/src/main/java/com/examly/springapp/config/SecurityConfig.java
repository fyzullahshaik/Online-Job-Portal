package com.examly.springapp.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Value("${ROLE_ADMIN}")
    private String admin;
    @Value("${ROLE_APPLICANT}")
    private String applicant;

    private UserDetailsService userDetailsService;

    private JwtAuthenticationFilter jwtAuthenticationFilter;

    private JwtAutheticationEntryPoint unauthorizedHandler;

    @Autowired
    public SecurityConfig(UserDetailsService userDetailsService, JwtAuthenticationFilter jwtAuthenticationFilter,
            JwtAutheticationEntryPoint unauthorizedHandler) {
        this.userDetailsService = userDetailsService;
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.unauthorizedHandler = unauthorizedHandler;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.csrf(csrf -> csrf.disable());
        httpSecurity.cors(Customizer.withDefaults());
        httpSecurity.authorizeHttpRequests(authorizeHttpRequest -> authorizeHttpRequest
                .requestMatchers(HttpMethod.POST , "/api/login", "/api/register").permitAll()
                .requestMatchers(HttpMethod.GET , "/api/job", "/api/application").permitAll()
                .requestMatchers(HttpMethod.POST , "/api/job").hasAuthority(admin)
                .requestMatchers(HttpMethod.PUT , "/api/job/{jobId}" , "/api/application/{applicationId}").hasAuthority(admin)
                .requestMatchers(HttpMethod.GET , "/api/payment").hasAuthority(admin)
                .requestMatchers(HttpMethod.DELETE , "/api/job/{jobId}").hasAuthority(admin)
                .requestMatchers(HttpMethod.GET , "/api/job/{jobId}", "/api/job/premium-job" , "/api/job/application/{jobId}").hasAnyAuthority(admin , applicant)
                .requestMatchers(HttpMethod.GET ,  "/api/application/user/{userId}" , "/api/payment/user/{userId}").hasAuthority(applicant)
                .requestMatchers(HttpMethod.POST , "/api/payment/{userId}" , "/api/application").hasAuthority(applicant)
                .requestMatchers(HttpMethod.DELETE , "/api/application/{applicationId}").hasAuthority(applicant)
                .anyRequest().authenticated())
                .sessionManagement(
                        sessionManager -> sessionManager.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .exceptionHandling(exceptionHandling -> exceptionHandling.authenticationEntryPoint(
                        unauthorizedHandler::commence))
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return httpSecurity.build();

    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userDetailsService);
        authenticationProvider.setPasswordEncoder(passwordEncoder());
        return authenticationProvider;

    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}
