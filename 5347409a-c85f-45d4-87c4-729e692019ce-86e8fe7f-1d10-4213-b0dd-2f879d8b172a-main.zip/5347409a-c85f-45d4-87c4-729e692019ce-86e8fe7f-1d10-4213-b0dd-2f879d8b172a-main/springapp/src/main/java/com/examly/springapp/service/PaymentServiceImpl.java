package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Payment;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.PaymentRepository;

import jakarta.transaction.Transactional;

@Service
public class PaymentServiceImpl implements PaymentService{
    private PaymentRepository paymentRepository;
    private UserServiceImpl userServiceImpl;

    @Autowired
    public PaymentServiceImpl(PaymentRepository paymentRepository, UserServiceImpl userServiceImpl) {
        this.paymentRepository = paymentRepository;
        this.userServiceImpl = userServiceImpl;
    }

    @Override
    @Transactional
    public List<Payment> getAllPayment() {
        return paymentRepository.findAll();
    }

    @Override
    @Transactional
    public Payment addPayment(Payment payment , long userId) {
        User payingUser = userServiceImpl.fetchUser(userId);
        payingUser.setPremiumUser(true);
        userServiceImpl.updateUser(payingUser);
        payment.setUser(payingUser);
        return paymentRepository.save(payment);
    }
    
    @Override
    @Transactional
    public List<Payment> getPaymentByUserId(long userId) {
        return paymentRepository.findByUserUserId(userId);
    }

}
