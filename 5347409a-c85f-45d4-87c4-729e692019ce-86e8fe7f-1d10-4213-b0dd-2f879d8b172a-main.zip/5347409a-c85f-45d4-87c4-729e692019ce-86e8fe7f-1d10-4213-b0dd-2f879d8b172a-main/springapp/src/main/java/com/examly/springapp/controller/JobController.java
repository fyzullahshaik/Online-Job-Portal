package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Job;
import com.examly.springapp.service.JobServiceImpl;

@RestController
@RequestMapping("/api/")
public class JobController {
    private JobServiceImpl jobServiceImpl;

    @Autowired
    public JobController(JobServiceImpl jobServiceImpl) {
        this.jobServiceImpl = jobServiceImpl;
    }

    @PostMapping("job")
    public ResponseEntity<Job> createJob(@RequestBody Job job) {
        return new ResponseEntity<>(jobServiceImpl.addJob(job), HttpStatus.CREATED);
    }

    @GetMapping("job")
    public ResponseEntity<List<Job>> fetchAllJobs() {
        return new ResponseEntity<>(jobServiceImpl.getAllJobs(), HttpStatus.OK);
    }

    @GetMapping("job/{jobId}")
    public ResponseEntity<Job> fetchJobDetails(@PathVariable("jobId") long jobId) {
        return new ResponseEntity<>(jobServiceImpl.getJobById(jobId), HttpStatus.OK);
    }

    @DeleteMapping("job/{jobId}")
    public ResponseEntity<String> deleteJobDetails(@PathVariable("jobId") long jobId) {
        return new ResponseEntity<>(jobServiceImpl.deleteJob(jobId), HttpStatus.OK);
    }

    @PutMapping("job/{jobId}")
    public ResponseEntity<Job> updateJobDetails(@RequestBody Job job, @PathVariable("jobId") long jobId) {
        return new ResponseEntity<>(jobServiceImpl.updateJob(jobId, job), HttpStatus.OK);
    }

    @GetMapping("job/premium-job")
    public ResponseEntity<List<Job>> fetchPremiumJobs() {
        return new ResponseEntity<>(jobServiceImpl.getPremiumJobs(), HttpStatus.OK);
    }

}
