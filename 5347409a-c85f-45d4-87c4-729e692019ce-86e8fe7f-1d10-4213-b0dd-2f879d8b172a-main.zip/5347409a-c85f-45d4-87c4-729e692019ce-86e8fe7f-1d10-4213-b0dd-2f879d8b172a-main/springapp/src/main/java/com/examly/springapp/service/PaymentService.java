package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.model.Payment;

public interface PaymentService {
    public List<Payment> getAllPayment();
    public Payment addPayment(Payment payment , long userId);
    public List<Payment> getPaymentByUserId(long userId);
}
