package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.ApplicationNotFoundException;
import com.examly.springapp.model.Application;
import com.examly.springapp.repository.ApplicationRepository;

import jakarta.transaction.Transactional;

@Service
public class ApplicationServiceImpl implements ApplicationService {
    private ApplicationRepository applicationRepo;

    private UserServiceImpl userServiceImpl;
    
    
    @Autowired
    public ApplicationServiceImpl(ApplicationRepository applicationRepo, UserServiceImpl userServiceImpl) {
        this.applicationRepo = applicationRepo;
        this.userServiceImpl = userServiceImpl;
    }

    @Override
    @Transactional
    public Application getApplicationById(long applicationId) {
        Optional<Application> application = applicationRepo.findById(applicationId);
        if(application.isPresent()){
            return application.get();
        }else{
            throw new ApplicationNotFoundException("No application found with"+applicationId);
        }
    }

    @Override
    @Transactional
    public List<Application> getApplicationByUserId(long userId) {
        return userServiceImpl.fetchUserApplications(userId);        
    }

    @Override
    @Transactional
    public List<Application> getAllApplications() {
       return applicationRepo.findAll();
    }

    @Override
    @Transactional
    public Application addApplication(Application application) {
       return applicationRepo.save(application);
    }

    @Override
    @Transactional
    public String deleteApplication(long applicationId) {
        applicationRepo.deleteById(applicationId);
        return applicationRepo.findById(applicationId).isPresent() ? "Failed to delete Application": "Application deleted Successfully!!";
    }

    @Transactional
    public List<Application> getJobApplications(long jobId)
    {
        return applicationRepo.findByJob_JobId(jobId);
    }

    @Transactional
    public String updateApplicationStatus(long applicationId , String status)
    {
        Application application = applicationRepo.findById(applicationId).orElse(null);
        if (application != null) {
            application.setStatus(status);
            applicationRepo.save(application);
            return "Application Status Changed Successfully";
        } else {
            return "Failed to update application status";   
        }
    }

    @Transactional
    public boolean checkJobApplications(long jobId)
    {
        return applicationRepo.existsByJob_JobId(jobId);
    }

}
