package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.exception.JobDeletionFailedException;
import com.examly.springapp.exception.JobNotFoundException;
import com.examly.springapp.model.Job;
import com.examly.springapp.repository.JobRepository;

import jakarta.transaction.Transactional;
@Service
public class JobServiceImpl implements JobService{

    private JobRepository jobRepository;

    private ApplicationServiceImpl applicationServiceImpl;
    
    @Autowired
    public JobServiceImpl(JobRepository jobRepository , ApplicationServiceImpl applicationServiceImpl)
    {
        this.jobRepository = jobRepository;
        this.applicationServiceImpl = applicationServiceImpl;
    }


    @Transactional
    public Job addJob(Job job) {
        return jobRepository.save(job); 
    }
    @Transactional
    public List<Job> getAllJobs() {
        return jobRepository.findByCategory("General");
    }
    @Transactional
    public Job updateJob(long jobId , Job job) {
        if (jobRepository.existsById(jobId)) {
            return jobRepository.save(job);
        }
        throw new JobNotFoundException("Requested Job details not found");
    }
    @Transactional
    public String deleteJob(long jobId) {
        if (!applicationServiceImpl.checkJobApplications(jobId)) {
            jobRepository.deleteById(jobId);
            return jobRepository.existsById(jobId) ? "Failed to delete specified job" : "Job Deleted successfully!!";
        } else {
            throw new JobDeletionFailedException("Failed to delete job as applications exists");
        }
    }
    @Transactional
    public Job getJobById(long jobId) {
        return jobRepository.findById(jobId).orElseThrow(()->new JobNotFoundException("Requested Job details not found"));
    }
    @Transactional
    public List<Job> getPremiumJobs() {
        return jobRepository.findByCategory("Premium");
    }

}
